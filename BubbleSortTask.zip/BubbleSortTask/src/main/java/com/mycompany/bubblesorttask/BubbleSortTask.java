/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.bubblesorttask;

/**
 * @author prince
 */

public class BubbleSortTask {

    // Sorts an array of integers using the bubble sort algorithm
    
    public static void bubbleSort(int[] array) {
        int n = array.length;

        // Outer loop: tracks how many passes have been made
        
        for (int i = 0; i < n - 1; i++) {
            // Inner loop: compares adjacent elements, shrinks range by i each pass

            for (int j = 0; j < n - i - 1; j++) {
                
                // If the current element is bigger than the next, swap them
                
                if (array[j] > array[j + 1]) {
                    int temp = array[j];
                    array[j] = array[j + 1];
                    array[j + 1] = temp;
                }
            }
        }
    }

    // Prints the contents of an array on one line

    public static void printArray(int[] array) {
        for (int value : array) {
            System.out.print(value + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        int[] numbers = {5, 2, 9, 1, 6};

        System.out.print("Before sorting: ");
        printArray(numbers);

        bubbleSort(numbers);

        System.out.print("After sorting:  ");
        printArray(numbers);
    }
}
